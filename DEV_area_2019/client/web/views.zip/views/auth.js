module.exports = {
    'googleAuth' : {
        'clientID': '156679486932-3e273n82c05jiqgb4pk8k101r1bor6au.apps.googleusercontent.com',
        'clientSecret': 'KER0kzcZT0eFArxmLG3HrA17',
        'callbackURL': 'http://localhost:8080/auth/google/callback'
    }
}